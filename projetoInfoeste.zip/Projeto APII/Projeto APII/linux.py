import cherrypy

class pageLinux():
    topo = open("HTMLS/cabeçalho.html",encoding="utf-8") .read()
    linux = open("HTMLS/linux.html",encoding="utf-8") . read()

    @cherrypy.expose()
    def index(self):
        html = self.topo
        html += self.linux
        return html