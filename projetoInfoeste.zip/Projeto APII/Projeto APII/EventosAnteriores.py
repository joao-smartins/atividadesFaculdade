import cherrypy

class pageEventos():
    topo = open("HTMLS/cabeçalho.html",encoding="utf-8") .read()
    eventos = open("HTMLS/anteriores.html",encoding="utf-8") . read()

    @cherrypy.expose()
    def index(self):
        html = self.topo
        html += self.eventos
        return html