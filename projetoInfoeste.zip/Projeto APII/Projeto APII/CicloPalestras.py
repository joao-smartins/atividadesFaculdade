import cherrypy

class pagePalestras():
    topo = open("HTMLS/cabeçalho.html",encoding="utf-8") .read()
    palestras = open("HTMLS/palestra.html",encoding="utf-8") . read()

    @cherrypy.expose()
    def index(self):
        html = self.topo
        html += self.palestras
        return html