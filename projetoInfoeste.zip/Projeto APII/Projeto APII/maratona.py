import cherrypy

class pagemaratona():
    topo = open("HTMLS/cabeçalho.html",encoding="utf-8") .read()
    maratona = open("HTMLS/maratona.html",encoding="utf-8") . read()

    @cherrypy.expose()
    def index(self):
        html = self.topo
        html += self.maratona
        return html