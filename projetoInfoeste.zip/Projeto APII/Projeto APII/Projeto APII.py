import cherrypy
import os

local_dir = os.path.dirname(__file__)
from EventosAnteriores import pageEventos
from PortFolios import pagePortFolios
from CicloPalestras import pagePalestras
from linux import pageLinux
from fippetec import pagefippetec
from maratona import pagemaratona
from Inscrição import pageInscrição

class Principal():
    topo = open("HTMLS/cabeçalho.html",encoding="utf-8").read()
    principal = open("HTMLS/Principal.html",encoding="utf-8").read()
    @cherrypy.expose()
    def index(self):
        html = self.topo
        html = html + self.principal
        return html

server_config={
'server.socket_host': '127.0.0.1',
'server.socket_port': 80
}
cherrypy.config.update(server_config)


local_config = {
    "/":{"tools.staticdir.on":True,
         "tools.staticdir.dir":local_dir},
}


root = Principal() #rota principal
root.rotaeventos = pageEventos()
root.rotaportfolios = pagePortFolios()
root.rotapalestras = pagePalestras()
root.rotalinux = pageLinux()
root.rotafippetec = pagefippetec()
root.rotamaratona = pagemaratona()
root.rotainscrição = pageInscrição()

cherrypy.quickstart(root,config=local_config)
