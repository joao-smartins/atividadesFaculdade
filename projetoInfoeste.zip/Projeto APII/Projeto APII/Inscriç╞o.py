import cherrypy
from classes.classe_inscricao import *

class pageInscrição():

    topo = open("HTMLS/cabeçalho.html",encoding="utf-8") .read()
    inscrição = open("HTMLS/inscricao.html",encoding="utf-8") . read()

    @cherrypy.expose()
    def index(self):
        html = self.montarformulario()
        return html

    # ==============================================================
    def montarformulario(self, pid=0, pcpf='', pnome='', porcurso='', ppale='',pcam=''):
        html = self.topo
        html += '''
        <style>
            
            *{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}
            
            #inscricao { display: flex; justify-content: center; }

            article {padding-top: 120px;}
            
            #dados {
                margin-top: 40px;
                width: 1050px;
                background-color: azure;
                border-radius: 10px;
                padding: 10px;
                box-shadow: 0px 3px 10px black;
                margin-bottom: 40px;}
                
            #dados input, button, select { border-radius: 15px; padding: 5px; }
            
            #dados fieldset { padding: 15px; border-radius: 15px; margin-bottom: 15px; }
            
            #dados legend {
                font-weight: bold;
                background: linear-gradient( to right, black, green, blue );
                background-clip: text;
                -webkit-background-clip: text; -webkit-text-fill-color: transparent;
                color: black;
                border: solid 2px; border-radius: 15px;
                padding: 7px;}
            
            #texto { display: flex; flex-direction: column;
            justify-content: center; align-items: center; }
           
           #paragrafo {
            font-size: 20px; margin-top: 20px;
            width: 1050px; text-align: justify;
            columns: 30px 2; column-gap: 30px;}
            
            #teste {
            background: linear-gradient( to right, black, green, blue );
            background-clip: text; -webkit-background-clip: text; 
            -webkit-text-fill-color: transparent; color: black; font-size:30px}
            
            .black { font-weight: bold; }

        </style>
        
        <article id="texto">
        <h1 id="teste">INSCRIÇÕES</h1>
        <div id="paragrafo">Ás inscrições abrirão no dia <span class="black"> 10 de Outubro de 2023 ás 17:00</span> e
            serão encerradas <span class="black">ás 17:00 do dia 21 de
                Outubro de 2023</span>. O valor da inscrição padrão é de <span class="black">R$ 35,00</span> , com
            direito á camiseta da Infoeste, garrafa
            térmica e copo (genérico) inclusos. Os eventos ocorrerão dos dias <span class="black">24 a 28 de
                Outubro</span>, no período matutino e
            noturno, contando com
            diversas palestras e cursos. <span class="black">Os primeiros 400 inscritos</span> serão afortunados com um
            vale "chopada", patrocinado
            pela refinadíssima House Sport Bar
            então corra e garanta logo o seu lugar!</div>
        </article>
        
        <section id="inscricao">
            <fieldset id="dados">
                <legend>
                <h2>DADOS</h2>
                </legend>
                <form name="FormCadastro" action="gravarInscricao" method="post">
                <p>
                 <input type="hidden" id="txtid" name="txtid" value="%s"/>
                 
                 <label for="txtcpf">CPF: </label>
                 <input placeholder="XXX.XXX.XXX-XX" type="text" id="txtcpf" pattern="\d{3}\.?\d{3}\.?\d{3}-?\d{2}" name="txtcpf" value="%s" size="20" maxlength="30" required="required" />
                 
                 <label for="txtnome">Nome Completo: </label>
                
                 <input placeholder="Digite seu nome:" type="text" id="txtnome" name="txtnome" value="%s" size="20" maxlength="60" required="required"/>
                 <br/> <br>
                 
                 <fieldset>
                     <legend>
                        <h3>Opções Evento</h3>
                    </legend>
                    
                     Curso:<br/>
                     <select name="txtcurso" id="txtcurso name="txtcurso" value="%s"  required="required"> Tipo
                            <option value="NULO">--------Selecione--------</option>
                            <option value="Excel">Excel</option>
                            <option value="Python">Python</option>
                            <option value="Linux">Linux</option>
                            <option value="Java">Java</option>
                            <option value="HTML 5">HTML 5</option>
                     </select>
                 
                 
                     <br/> Palestra:<br/>
                     <select name="txtpalestra" id="txtpalestra name="txtpalestra" value="%s"  required="required"> Tipo
                            <option value="NULO">--------Selecione--------</option>
                            <option value="IA">IA</option>
                            <option value="Egressos FIPP">Egressos FIPP</option>
                            <option value="Ciência de Dados">Ciência de Dados</option>
                            <option value="Totvs">Totvs</option>
                            <option value="Microsft">Microsoft</option>
                     </select>    
                 
                 </fieldset>   
                 
                 <fieldset>
                    
                    <legend>
                        <h3>Camiseta</h3>
                    </legend>
                    
                     Tamanho Camiseta:<br/>
                     <select name="txtcamiseta" id="txtcamiseta name="txtcamiseta" value="%s"  required="required"> Tipo
                            <option value="NULO">--------Selecione--------</option>
                            <option value="PP">PP</option>
                            <option value="P">P</option>
                            <option value="M">M</option>
                            <option value="G">G</option>
                            <option value="GG">GG</option>
                            <option value="EXG">EXG</option>
                        </select>   
                 
                 </fieldset>
                 
                 
                </p>
                <br/>
                <input type="submit" id="btnGravar" name="btnGravar" value="Gravar"/>
                
                <input type="reset" name="enviar" value="Limpar Formulário">
                
                </form><br/><hr/>
            </fieldset>    
         </section>     
         
            ''' % (pid, pcpf, pnome, porcurso, ppale, pcam)
        html += self.montartabela()

        html += '''
        <style>
            #div_img{
                display: flex;
                flex-direction: row;
                flex-wrap: wrap;
                text-align: center;
                justify-content: space-around;}
        
            #div_img h1{
                border: 1 px solid white;
                box-shadow: 0 3px 10px;
                border-radius: 15px;
                background: linear-gradient( to right, black, green, blue );
                background-clip: text;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                color: black;}
        
        </style>
        
        <aside id="div_img">
            <figure>
                <figcaption><h1>CAMISETA</h1></figcaption>
                <img src="/img/img_inscr/camiseta_programa.png" alt="camiseta preta como estampa" class="foto">
                
            </figure>
    
            <figure>
                <figcaption><h1>COPO GENÉRICO</h1></figcaption>
                <img src="/img/img_inscr/copo_tim-removebg.png" alt="copo da tim, azul" class="foto">
            </figure>
            </aside>
        '''
        return html

    # ==============================================================
    def montartabela(self):
        html = '''
        <style>
             *{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}
             
             h1{text-align: center;font-weight: bold;
                background: linear-gradient( to right, black, green, blue );
                background-clip: text;
                -webkit-background-clip: text; -webkit-text-fill-color: transparent;
                color: black;
                padding: 7px;}
                
            .alinha{ display: flex; justify-content: center; padding: 10px; margin: 20px;}

            .alinha td{ box-shadow: 0px 2px 5px; padding:10px; border-radius: 10px; font-size:20px; margin: 10px;}
        </style>
        
        <br/>
        <h1> LISTA DE INSCRITOS </h1>
        <table class="alinha">
                <tr>
                <th>ID</th>
                <th>CPF</th>
                <th>NOME</th>
                <th>CURSO</th>
                <th>PALESTRA</th>
                <th>CAMISETA</th>
                <th>OPÇÕES</th>
                </tr>
        
              '''

        objinscricao = Inscricao()
        dados = objinscricao.obterInscricoes()
        for ins in dados:
            html += '''<tr>
                     <td> %s </td>
                     <td> %s </td>
                     <td> %s </td>
                     <td> %s </td>
                     <td> %s </td>
                     <td> %s </td>
                     <td style="text-align:center;"> 
                        <a href="excluirInscricao?id=%s">[Excluir]</a>
                        <a href="alterarInscricao?id=%s">[Alterar]</a>
                     </td>
                    </tr>''' % (
            ins['ins_id'], ins['ins_cpf'], ins['ins_nome'],ins['ins_curso'], ins['ins_pal'],ins['ins_cam'], ins['ins_id'], ins['ins_id'])
        html += '</table><br/>'
        return html

    # ==============================================================
    @cherrypy.expose()
    def gravarInscricao(self, txtid, txtcpf, txtnome, txtcurso, txtpalestra, txtcamiseta, btnGravar):
        if len(txtcpf) > 0:
            objInscricao = Inscricao()
            objInscricao.set_cpf(txtcpf)
            objInscricao.set_nome(txtnome)
            objInscricao.set_curso(txtcurso)
            objInscricao.set_palestra(txtpalestra)
            objInscricao.set_camiseta(txtcamiseta)
            retorno = 0
            if int(txtid) == 0:
                retorno = objInscricao.gravar()
            else:
                objInscricao.set_id(int(txtid))
                retorno = objInscricao.alterar()
            if retorno > 0:
                return '''
                    <script>
                      alert("O usuário %s foi inscrito!")
                      window.location.href='/rotainscrição'
                    </script>
                ''' % (txtnome)
            else:
                return '''<h2>Erro ao efetuar a inscrição</h2>
                <a href="/rotainscrição">Voltar</a>
                '''
        else:
            return '''<h2>CPF  não informado!</h2>
                          <a href="">Voltar</a>'''

    # =======================================================================
    @cherrypy.expose()
    def excluirInscricao(self, id):
        objInscricao = Inscricao()
        objInscricao.set_id(int(id))
        if objInscricao.excluir() > 0:
            raise cherrypy.HTTPRedirect('/rotainscrição')
        else:
            return '''
            <h2>Não foi possível cancelar a inscrição!!</h2>
            [<a href="/rotainscrição">Voltar</a>]
            '''

    # ==============================================================
    @cherrypy.expose()
    def alterarInscricao(self, id):
        objInscricao = Inscricao()
        dadosInscricao = objInscricao.obterInscricao(id)
        return self.montarformulario(dadosInscricao[0]['ins_id'],
                                     dadosInscricao[0]['ins_cpf'],
                                     dadosInscricao[0]['ins_nome'],
                                     dadosInscricao[0]['ins_curso'],
                                     dadosInscricao[0]['ins_pal'],
                                     dadosInscricao[0]['ins_cam'])