from classes.banco import *

class Inscricao():
    def __init__(self):
        self.__id = 0
        self.__cpf = ''
        self.__nome = ''
        self.__curso = ''
        self.__palestra = ''
        self.__camiseta = ''
        self.__banco = Banco()


    def set_id(self,pid):
        if pid>0:
            self.__id=pid

    def set_cpf(self,pcpf):
        if len(pcpf) > 0:
            self.__cpf=pcpf

    def set_nome(self,pnome):
        if len(pnome)>0:
            self.__nome=pnome

    def set_curso(self,porcurso):
        if len(porcurso)>0:
            self.__curso=porcurso

    def set_palestra(self,ppale):
        if len(ppale)>0:
            self.__palestra=ppale

    def set_camiseta(self, pcam):
        if len(pcam) > 0:
            self.__camiseta = pcam


    def get_id(self):
        return self.__id

    def get_descricao(self):
        return self.__cpf

    def get_origem(self):
        return self.__nome

    def get_curso(self):
        return self.__curso

    def get_palestra(self):
        return self.__palestra

    def get_camiseta(self):
        return self.__camiseta



    # ==============================================================

    def obterInscricoes(self):
        sql = '''select ins_id, ins_cpf, ins_nome, ins_curso, ins_pal, ins_cam
                     from Inscricao Order by ins_id'''
        return self.__banco.executarSelect(sql)

    # ==============================================================

    def gravar(self):
        sql='''insert into Inscricao (ins_cpf,ins_nome,ins_curso,ins_pal,ins_cam) values("#cpf","#nome","#curso","#palestra", "#camiseta")'''
        sql=sql.replace('#cpf',self.__cpf)
        sql=sql.replace('#nome',self.__nome)
        sql = sql.replace('#curso', self.__curso)
        sql = sql.replace('#palestra', self.__palestra)
        sql = sql.replace('#camiseta', self.__camiseta)
        return self.__banco.executarInsertUpdateDelete(sql)

    #==============================================================

    def obterInscricao(self, pid=0):
        if pid != 0:
            self.__id = pid
        sql = ''' SELECT ins_id, ins_cpf,ins_nome, ins_curso, ins_pal, ins_cam
                  FROM Inscricao
                  where ins_id = #id         '''
        sql = sql.replace('#id', str(self.__id))
        return self.__banco.executarSelect(sql)

    # ==============================================================
    def excluir(self):
        sql = 'delete from Inscricao where ins_id = #id'
        sql = sql.replace('#id', str(self.__id))
        return self.__banco.executarInsertUpdateDelete(sql)

    # ==============================================================
    def alterar(self):
        sql = 'update Inscricao set ins_cpf = "#cpf", ins_nome = "#nome", ins_curso = "#curso", ins_pal = "#palestra", ins_cam = "#camiseta" where ins_id = #id'
        sql = sql.replace('#cpf', self.__cpf)
        sql = sql.replace('#nome',self.__nome)
        sql = sql.replace('#curso', self.__curso)
        sql = sql.replace('#palestra', self.__palestra)
        sql = sql.replace('#camiseta', self.__camiseta)
        sql = sql.replace('#id',str(self.__id))
        return self.__banco.executarInsertUpdateDelete(sql)