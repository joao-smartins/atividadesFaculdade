import cherrypy

class pagePortFolios():
    topo = open("HTMLS/cabeçalho.html",encoding="utf-8") .read()
    portfolios = open("HTMLS/portfolios.html",encoding="utf-8") . read()

    @cherrypy.expose()
    def index(self):
        html = self.topo
        html += self.portfolios
        return html